# Public Site Prototype

This is a static prototype for the public-facing database.

This directory is the deployable static site root.

Open `index.html` in a browser to test:

- keyword search
- region/entity/event filters
- record cards with Japanese and English titles
- public tags
- links to official MOFA material pages
- detail pages such as `record.html?id=mofa_100_013444`

Data is generated from:

- `outputs/public_search_index_v01.csv`
- `outputs/public_records_v01.csv`

The browser reads:

- `public_site/data/search_index.js`
- `public_site/data/public_records.js`

Regenerate the data files after updating the source CSVs.

Deployment targets:

- GitHub Pages: publish this directory through the root workflow `.github/workflows/deploy-pages.yml`.
- Netlify: `netlify.toml` sets `public_site` as the publish directory.
- Vercel: `vercel.json` sets `public_site` as the output directory.
